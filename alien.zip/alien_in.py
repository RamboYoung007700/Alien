import pygame
import settings
from ship import Ship
import gamefunctions as gf
from pygame.sprite import Group


def run_game():
    pygame.init()
    ai_settings=settings.Settings()
    screen = pygame.display.set_mode(
        (ai_settings.screen_width,ai_settings.screen_height))
    pygame.display.set_caption("外星人入侵")

    ship=Ship(screen,ai_settings)
    bullets=Group()
    
    
    while True:
        gf.check_events(ai_settings,screen,ship,bullets)
        ship.update()
        gf.update_bullets(bullets) 
        gf.update_screen(ai_settings,screen,ship,bullets)
        
run_game()

